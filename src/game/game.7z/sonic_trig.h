#ifndef _SONIC_TRIG_H
#define _SONIC_TRIG_H

#include <ultra64.h>

f64 Sonic_Asin(f64 x);
f64 Sonic_Acos(f64 x);

#endif
