#ifndef _SONIC_AIR_H
#define _SONIC_AIR_H

#include "sonic.h"

void Sonic_AirMovement(SonicState *s);

#endif
